﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Finalproject
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void userPass_TextChanged(object sender, EventArgs e)
        {
            userPass.UseSystemPasswordChar = true;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection(@"Data Source=LAPTOP-TDCMTRQT\SQLEXPRESS;Initial Catalog=Staff;Integrated Security=True");
            String sSQL = "Select userName,userPass from StaffInfo where userName ='" + userName.Text + "' and userPass ='" + userPass.Text + "'";
            SqlCommand cmd = new SqlCommand(sSQL, conn);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            if (dt.Rows.Count > 0)
            {

                MessageBox.Show("Login Successful");
                Homepage hp = new Homepage();
                this.Hide();
                hp.Show();
            }
            else
            {
                MessageBox.Show("Incorrect Username or Password");
            }
        }
    }
}