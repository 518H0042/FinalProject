select * from StaffInfo
insert into StaffInfo values ('Tien','abc123')